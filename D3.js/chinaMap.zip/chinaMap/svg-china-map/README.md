svg-china-map
=============

基于d3.js的svg中国地图实例

china_map.html 该例子的主文件

china.geo.json  是中国地图的GeoJSON

教程详见[http://www.waylau.com/svg-demo-china-map/](http://www.waylau.com/svg-demo-china-map/)
