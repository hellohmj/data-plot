# chinaMap
基于d3.js绘制中国地图及各省地图。  
支持根据数据计算渐变颜色渲染各省背景；支持鼠标移入显示省份名称及该省数据；支持鼠标点击省，显示该省地图。

## 使用说明：
1. 下载压缩文件解压
2. npm install 安装依赖库，npm install in china
3. npm run start 启动项目 ，npm run start 
4. 访问 localhost:3000，在浏览器地址栏中输入localhost:3000
